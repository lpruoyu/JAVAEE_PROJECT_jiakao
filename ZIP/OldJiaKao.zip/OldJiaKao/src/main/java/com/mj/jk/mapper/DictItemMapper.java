package com.mj.jk.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mj.jk.pojo.po.DictItem;

public interface DictItemMapper extends BaseMapper<DictItem> {

}
