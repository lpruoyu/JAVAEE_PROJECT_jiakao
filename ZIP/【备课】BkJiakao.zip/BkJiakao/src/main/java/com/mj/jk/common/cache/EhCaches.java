package com.mj.jk.common.cache;

import com.mj.jk.pojo.dto.SysUserDto;
import org.ehcache.Cache;
import org.ehcache.CacheManager;
import org.ehcache.config.builders.CacheManagerBuilder;
import org.ehcache.xml.XmlConfiguration;

import java.io.Serializable;
import java.net.URL;

public class EhCaches {
    private static final CacheManager mgr;
    private static final String DEFAULT = "default";
    private static final String TOKEN = "token";
    private static final Cache<Serializable, Serializable> DEFAULT_CACHE;
    private static final Cache<String, SysUserDto> TOKEN_CACHE;
    static {
        URL url = EhCaches.class.getClassLoader().getResource("ehcache.xml");
        assert url != null;
        mgr = CacheManagerBuilder.newCacheManager(new XmlConfiguration(url));
        mgr.init();

        DEFAULT_CACHE = mgr.getCache(DEFAULT, Serializable.class, Serializable.class);
        TOKEN_CACHE = mgr.getCache(TOKEN, String.class, SysUserDto.class);
    }

    public static <K extends Serializable, V extends Serializable> V get(K key) {
        if (key == null) return null;
        return (V) DEFAULT_CACHE.get(key);
    }

    public static <K extends Serializable, V extends Serializable> void put(K key, V value) {
        if (key == null || value == null) return;
        DEFAULT_CACHE.put(key, value);
    }

    public static <K extends Serializable> void remove(K key) {
        if (key == null) return;
        DEFAULT_CACHE.remove(key);
    }

    public static SysUserDto tokenGet(String key) {
        if (key == null) return null;
        return TOKEN_CACHE.get(key);
    }

    public static void tokenPut(String key, SysUserDto value) {
        if (key == null || value == null) return;
        TOKEN_CACHE.put(key, value);
    }

    public static void tokenRemove(String key) {
        if (key == null) return;
        TOKEN_CACHE.remove(key);
    }

    public static void clear() {
        DEFAULT_CACHE.clear();
    }

    public static void tokenClear() {
        TOKEN_CACHE.clear();
    }
}
