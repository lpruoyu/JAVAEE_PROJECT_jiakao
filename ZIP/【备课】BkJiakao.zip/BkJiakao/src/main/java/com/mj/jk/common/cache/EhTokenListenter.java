package com.mj.jk.common.cache;

import com.mj.jk.pojo.dto.SysUserDto;
import lombok.extern.slf4j.Slf4j;
import org.ehcache.event.CacheEvent;
import org.ehcache.event.CacheEventListener;
import org.ehcache.event.EventType;

import java.io.Serializable;

@Slf4j
public class EhTokenListenter implements CacheEventListener<Serializable, Serializable> {
    @Override
    public void onEvent(CacheEvent<? extends Serializable, ? extends Serializable> cacheEvent) {
        EventType type = cacheEvent.getType();
        String token = (String) cacheEvent.getKey();
        switch (type) {
            case CREATED:
                SysUserDto newUser = (SysUserDto) cacheEvent.getNewValue();
                EhCaches.put(newUser.getId(), token);
                break;
            case REMOVED:
            case EXPIRED:
                SysUserDto oldUser = (SysUserDto) cacheEvent.getOldValue();
                EhCaches.remove(oldUser.getId());
                break;
            default:
                break;
        }
        log.debug("EhTokenCacheListenter - {} {}", token, type);
    }
}
