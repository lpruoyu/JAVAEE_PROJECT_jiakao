package com.mj.jk.common.foreign.anno;

import java.lang.annotation.*;

public enum ForeignCascade {
    DEFAULT, DELETE;

}
