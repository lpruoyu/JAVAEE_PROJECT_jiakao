package com.mj.jk.common.shiro;

import com.mj.jk.common.prop.JkProperties;
import com.mj.jk.filter.ErrorFilter;
import org.apache.shiro.realm.Realm;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.Filter;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

@Configuration
public class ShiroCfg {
    @Autowired
    private JkProperties properties;

    @Bean
    public Realm realm() {
        return new TokenRealm();
    }

    @Bean
    public ShiroFilterFactoryBean shiroFilterFactoryBean(Realm realm) {
        ShiroFilterFactoryBean bean = new ShiroFilterFactoryBean();
        // 设置管理器
        bean.setSecurityManager(new DefaultWebSecurityManager(realm));

        // token filter
        Map<String, Filter> filters = new HashMap<>();
        filters.put("token", new TokenFilter());
        bean.setFilters(filters);

        // 路径 - 权限映射
        Map<String, String> filterMap = new LinkedHashMap<>();
        filterMap.put("/sysUsers/login", "anon");
        filterMap.put("/sysUsers/captcha", "anon");
        filterMap.put("/swagger*/**", "anon");
        filterMap.put("/v2/api-docs/**", "anon");
        filterMap.put("/test/**", "anon");
        // 错误过滤器
        filterMap.put(ErrorFilter.ERROR_FILTER_URI, "anon");
        // 文件上传
        filterMap.put("/" + properties.getUpload().getUploadPath() + "**", "anon");
        // 其他
        filterMap.put("/**", "token");
        bean.setFilterChainDefinitionMap(filterMap);

        return bean;
    }

    /**
     * 解决：@RequiresPermissions导致控制器接口404
     */
    @Bean
    public DefaultAdvisorAutoProxyCreator proxyCreator() {
        DefaultAdvisorAutoProxyCreator proxyCreator = new DefaultAdvisorAutoProxyCreator();
        proxyCreator.setUsePrefix(true);
        return proxyCreator;
    }
}
