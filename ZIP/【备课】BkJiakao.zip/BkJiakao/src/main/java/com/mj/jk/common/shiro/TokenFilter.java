package com.mj.jk.common.shiro;

import com.mj.jk.common.shiro.Token;
import com.mj.jk.common.cache.EhCaches;
import com.mj.jk.common.util.JsonVos;
import com.mj.jk.common.util.Strings;
import com.mj.jk.pojo.dto.SysUserDto;
import com.mj.jk.pojo.result.CodeMsg;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.web.filter.AccessControlFilter;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

@Slf4j
public class TokenFilter extends AccessControlFilter {
    public static final String TOKEN_HEADER = "Token";

    /**
     * @return true会进入下一个链式调用（过滤器、拦截器、控制器），false就进入onAccessDenied，交给shiro处理
     */
    @Override
    protected boolean isAccessAllowed(ServletRequest req,
                                      ServletResponse resp, Object o) throws Exception {
        log.debug("isAccessAllowed");
        return false;
    }

    /**
     * @return true会进入下一个链式调用（过滤器、拦截器、控制器），false就不会进入
     */
    @Override
    protected boolean onAccessDenied(ServletRequest req,
                                     ServletResponse resp) throws Exception {
        // 获得请求
        HttpServletRequest request = (HttpServletRequest) req;
        log.debug("onAccessDenied - {}", request.getRequestURI());

        // 获得token
        String token = request.getHeader(TOKEN_HEADER);

        // token为空
        if (Strings.isEmpty(token)) {
            return JsonVos.raise(CodeMsg.EMPTY_ACCESS_TOKEN);
        }

        // 获取用户
        SysUserDto user = EhCaches.tokenGet(token);
        if (user == null) {
            return JsonVos.raise(CodeMsg.TOKEN_EXPIRED);
        }

        // 进行登录
        getSubject(req, resp).login(new Token(token));
        return true;
    }
}
