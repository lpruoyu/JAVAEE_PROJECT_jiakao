package com.mj.jk.common.shiro;

import com.mj.jk.common.cache.EhCaches;
import com.mj.jk.pojo.dto.SysUserDto;
import com.mj.jk.pojo.po.SysResource;
import com.mj.jk.pojo.po.SysRole;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;

@Slf4j
public class TokenRealm extends AuthorizingRealm {
    public TokenRealm() {
        super(new TokenMatcher());
    }

    @Override
    public boolean supports(AuthenticationToken token) {
        return token instanceof Token;
    }

    /**
     * 授权
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        log.debug("doGetAuthorizationInfo - {}", principals);
        // 拿到token
        String token = (String) principals.getPrimaryPrincipal();
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        SysUserDto user = EhCaches.tokenGet(token);
        // 添加角色
        for (SysRole role : user.getRoles()) {
            info.addRole(role.getName());
        }
        // 添加权限
        for (SysResource resource : user.getResources()) {
            info.addStringPermission(resource.getPermission());
        }
        return info;
    }

    /**
     * 认证
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        log.debug("doGetAuthenticationInfo - {}", token);
        Token tk = (Token) token;
        return new SimpleAuthenticationInfo(
                tk.getPrincipal(),
                tk.getCredentials(),
                getName());
    }
}
