package com.mj.jk.common.util;

public class Passwords {

}
