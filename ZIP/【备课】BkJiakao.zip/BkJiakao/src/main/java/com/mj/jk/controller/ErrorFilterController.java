package com.mj.jk.controller;

import com.mj.jk.filter.ErrorFilter;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
public class ErrorFilterController {
    @RequestMapping(ErrorFilter.ERROR_FILTER_URI)
    public void handle(HttpServletRequest request) throws Throwable {
        throw (Throwable) request.getAttribute(ErrorFilter.ERROR_FILTER);
    }
}
