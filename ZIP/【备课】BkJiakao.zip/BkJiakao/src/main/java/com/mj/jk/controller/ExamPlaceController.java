package com.mj.jk.controller;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mj.jk.common.mapStruct.MapStructs;
import com.mj.jk.common.util.JsonVos;
import com.mj.jk.pojo.vo.ProvinceVo;
import com.mj.jk.pojo.po.ExamPlace;
import com.mj.jk.pojo.vo.list.ExamPlaceVo;
import com.mj.jk.pojo.vo.req.save.ExamPlaceReqVo;
import com.mj.jk.pojo.vo.req.list.ExamPlaceListReqVo;
import com.mj.jk.pojo.vo.json.DataJsonVo;
import com.mj.jk.pojo.vo.json.ListJsonVo;
import com.mj.jk.service.ExamPlaceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/examPlaces")
@Api(tags = "考场")
public class ExamPlaceController extends BaseController<ExamPlace, ExamPlaceReqVo> {
    @Autowired
    private ExamPlaceService service;

    @GetMapping
    @ApiOperation("分页查询")
    public ListJsonVo<ExamPlaceVo> list(ExamPlaceListReqVo reqVo) {
        return JsonVos.ok(service.list(reqVo));
    }

    @GetMapping("/regions")
    @ApiOperation("查询所有区域下的考场")
    public DataJsonVo<List<ProvinceVo>> listRegionExamPlaces() {
        return JsonVos.ok(service.listRegionExamPlaces());
    }

    @Override
    protected IService<ExamPlace> getService() {
        return service;
    }

    @Override
    protected ExamPlace getPo(ExamPlaceReqVo reqVo) {
        return MapStructs.INSTANCE.reqVo2po(reqVo);
    }
}
