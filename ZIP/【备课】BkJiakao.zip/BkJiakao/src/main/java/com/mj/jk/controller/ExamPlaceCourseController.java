package com.mj.jk.controller;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mj.jk.common.mapStruct.MapStructs;
import com.mj.jk.common.util.JsonVos;
import com.mj.jk.common.util.Uploads;
import com.mj.jk.pojo.po.ExamPlaceCourse;
import com.mj.jk.pojo.po.Image;
import com.mj.jk.pojo.result.CodeMsg;
import com.mj.jk.pojo.vo.req.save.ExamPlaceCourseReqVo;
import com.mj.jk.pojo.vo.req.list.ExamPlaceCourseListReqVo;
import com.mj.jk.pojo.vo.json.ListJsonVo;
import com.mj.jk.pojo.vo.json.JsonVo;
import com.mj.jk.pojo.vo.list.ExamPlaceCourseVo;
import com.mj.jk.service.ExamPlaceCourseService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/examPlaceCourses")
@Api(tags = "科2科3课程")
public class ExamPlaceCourseController extends BaseController<ExamPlaceCourse, ExamPlaceCourseReqVo> {
    @Autowired
    private ExamPlaceCourseService service;

    @GetMapping
    @ApiOperation("分页查询")
    public ListJsonVo<ExamPlaceCourseVo> list(ExamPlaceCourseListReqVo reqVo) {
        return JsonVos.ok(service.list(reqVo));
    }

    @PostMapping("/saveAll")
    @ApiOperation("添加或更新（带有封面）")
    public JsonVo saveAll(ExamPlaceCourseReqVo courseReqVo, MultipartFile coverFile) throws Exception {
        Image image = Uploads.uploadImage(coverFile);
        if (service.saveOrUpdate(courseReqVo, image)) {
            return JsonVos.ok();
        }
        return JsonVos.raise(CodeMsg.SAVE_ERROR);
    }

    @PostMapping("/uploadVideo")
    @ApiOperation("上传视频")
    public JsonVo uploadVideo(MultipartFile videoFile, String id) throws Exception {
        String video = Uploads.uploadVideo(videoFile);
        if (video != null) {
            ExamPlaceCourse course = service.getById(id);
            if (course.getVideo() != null) {
                Uploads.remove(course.getVideo());
            }
            course.setVideo(video);
            if (service.saveOrUpdate(course)) {
                return JsonVos.ok(course);
            }
        }
        return JsonVos.raise(CodeMsg.SAVE_ERROR);
    }

    @Override
    protected IService<ExamPlaceCourse> getService() {
        return service;
    }

    @Override
    protected ExamPlaceCourse getPo(ExamPlaceCourseReqVo reqVo) {
        return MapStructs.INSTANCE.reqVo2po(reqVo);
    }
}
