package com.mj.jk.controller;

import com.mj.jk.common.util.JsonVos;
import com.mj.jk.common.util.Uploads;
import com.mj.jk.pojo.po.Image;
import com.mj.jk.pojo.result.CodeMsg;
import com.mj.jk.pojo.vo.json.DataJsonVo;
import com.mj.jk.pojo.vo.json.JsonVo;
import com.mj.jk.service.ImageService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/images")
@Api(tags = "图片")
public class ImageController {
    @Autowired
    private ImageService service;

    @GetMapping
    @ApiOperation("查询图片")
    public DataJsonVo<List<Image>> list(Long ownerId, Short type) {
        return JsonVos.ok(service.list(ownerId, type));
    }

    @PostMapping("/remove")
    @ApiOperation("删除图片")
    public JsonVo remove(String id) {
        Image image = service.getById(id);
        if (service.removeById(id)) {
            Uploads.remove(image);
            return JsonVos.ok();
        }
        return JsonVos.raise(CodeMsg.REMOVE_ERROR);
    }

    @PostMapping("/save")
    @ApiOperation("添加图片")
    public DataJsonVo<List<Image>> save(MultipartFile[] files, Image imageParam)
            throws Exception {
        Long ownerId = imageParam.getOwnerId();
        if (ownerId == null || ownerId < 1) {
            return JsonVos.raise("缺少图片拥有者的ID");
        }
        Short type = imageParam.getType();
        if (type == null) {
            return JsonVos.raise("缺少图片拥有者的类型");
        }

        List<Image> images = new ArrayList<>();
        for (MultipartFile file : files) {
            Image imageObj = Uploads.uploadImage(file);
            if (imageObj == null) continue;

            imageObj.setOwnerId(ownerId);
            imageObj.setType(type);
            service.save(imageObj);

            imageObj.setOwnerId(null);
            imageObj.setType(null);
            images.add(imageObj);
        }

        return JsonVos.ok(images);
    }
}
