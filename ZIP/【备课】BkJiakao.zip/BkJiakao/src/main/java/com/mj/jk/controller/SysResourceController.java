package com.mj.jk.controller;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mj.jk.common.mapStruct.MapStructs;
import com.mj.jk.common.util.Constants;
import com.mj.jk.common.util.JsonVos;
import com.mj.jk.common.util.Streams;
import com.mj.jk.pojo.po.SysResource;
import com.mj.jk.pojo.vo.list.SysResourceTreeVo;
import com.mj.jk.pojo.vo.list.SysResourceVo;
import com.mj.jk.pojo.vo.req.save.SysResourceReqVo;
import com.mj.jk.pojo.vo.json.DataJsonVo;
import com.mj.jk.service.SysResourceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/sysResources")
@Api(tags = "系统资源")
public class SysResourceController extends BaseController<SysResource, SysResourceReqVo> {
    @Autowired
    private SysResourceService service;

    @Override
    protected IService<SysResource> getService() {
        return service;
    }

    @Override
    protected SysResource getPo(SysResourceReqVo reqVo) {
        return MapStructs.INSTANCE.reqVo2po(reqVo);
    }

    @GetMapping("/list")
    @ApiOperation("查询所有")
    @RequiresPermissions(Constants.Permisson.SYS_RESOURCE_LIST)
    public DataJsonVo<List<SysResourceVo>> list() {
        return JsonVos.ok(Streams.map(service.list(), MapStructs.INSTANCE::po2vo));
    }

    @GetMapping("/trees")
    @ApiOperation("查询所有（树状结构展示）")
    @RequiresPermissions(Constants.Permisson.SYS_RESOURCE_LIST)
    public DataJsonVo<List<SysResourceTreeVo>> listTrees() {
        return JsonVos.ok(service.listTrees());
    }

    @GetMapping("/parents")
    @ApiOperation("查询所有的父资源")
    @RequiresPermissions(Constants.Permisson.SYS_RESOURCE_LIST)
    public DataJsonVo<List<SysResourceVo>> listParents() {
        return JsonVos.ok(service.listParents());
    }
}