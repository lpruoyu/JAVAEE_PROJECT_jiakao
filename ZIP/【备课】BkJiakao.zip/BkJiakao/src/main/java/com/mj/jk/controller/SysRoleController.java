package com.mj.jk.controller;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mj.jk.common.mapStruct.MapStructs;
import com.mj.jk.common.util.Constants;
import com.mj.jk.common.util.JsonVos;
import com.mj.jk.pojo.po.SysRole;
import com.mj.jk.pojo.result.CodeMsg;
import com.mj.jk.pojo.vo.json.JsonVo;
import com.mj.jk.pojo.vo.list.SysRoleVo;
import com.mj.jk.pojo.vo.req.save.SysRoleReqVo;
import com.mj.jk.pojo.vo.req.list.SysRoleListReqVo;
import com.mj.jk.pojo.vo.json.DataJsonVo;
import com.mj.jk.pojo.vo.json.ListJsonVo;
import com.mj.jk.service.SysRoleResourceService;
import com.mj.jk.service.SysRoleService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/sysRoles")
@Api(tags = "角色")
public class SysRoleController extends BaseController<SysRole, SysRoleReqVo> {
    @Autowired
    private SysRoleService service;
    @Autowired
    private SysRoleResourceService roleResourceService;

    @Override
    protected IService<SysRole> getService() {
        return service;
    }

    @Override
    protected SysRole getPo(SysRoleReqVo reqVo) {
        return MapStructs.INSTANCE.reqVo2po(reqVo);
    }

    @GetMapping
    @ApiOperation("分页查询")
    @RequiresPermissions(Constants.Permisson.SYS_ROLE_LIST)
    public ListJsonVo<SysRoleVo> list(SysRoleListReqVo reqVo) {
        return JsonVos.ok(service.list(reqVo));
    }

    @GetMapping("/list")
    @ApiOperation("查询所有")
    @RequiresPermissions(Constants.Permisson.SYS_ROLE_LIST)
    public DataJsonVo<List<SysRole>> list() {
        return JsonVos.ok(service.list());
    }

    @Override
    @RequiresPermissions(value = {
            Constants.Permisson.SYS_ROLE_ADD,
            Constants.Permisson.SYS_ROLE_UPDATE
    }, logical = Logical.AND)
    public JsonVo save(SysRoleReqVo reqVo) {
        return service.save(reqVo)
                ? JsonVos.ok(CodeMsg.SAVE_OK)
                : JsonVos.raise(CodeMsg.SAVE_ERROR);
    }

    @GetMapping("/resourceIds")
    @ApiOperation("查询某个角色下的所有资源id")
    @RequiresPermissions(Constants.Permisson.SYS_ROLE_LIST)
    public DataJsonVo<List<Short>> listResourceIds(Integer id) {
        return JsonVos.ok(roleResourceService.listResourceIdsByRoleId(id));
    }

    @Override
    @RequiresPermissions(Constants.Permisson.SYS_ROLE_REMOVE)
    public JsonVo remove(String id) {
        return super.remove(id);
    }
}