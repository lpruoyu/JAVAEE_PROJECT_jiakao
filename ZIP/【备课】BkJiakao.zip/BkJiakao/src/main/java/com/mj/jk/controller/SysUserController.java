package com.mj.jk.controller;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mj.jk.common.mapStruct.MapStructs;
import com.mj.jk.common.util.Constants;
import com.mj.jk.common.util.JsonVos;
import com.mj.jk.pojo.po.SysUser;
import com.mj.jk.pojo.vo.LoginVo;
import com.mj.jk.pojo.vo.list.SysUserVo;
import com.mj.jk.pojo.vo.req.save.SysUserReqVo;
import com.mj.jk.pojo.vo.req.list.SysUserListReqVo;
import com.mj.jk.pojo.result.CodeMsg;
import com.mj.jk.pojo.vo.req.LoginReqVo;
import com.mj.jk.pojo.vo.json.DataJsonVo;
import com.mj.jk.pojo.vo.json.ListJsonVo;
import com.mj.jk.pojo.vo.json.JsonVo;
import com.mj.jk.service.SysUserRoleService;
import com.mj.jk.service.SysUserService;
import com.wf.captcha.utils.CaptchaUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

@RestController
@RequestMapping("/sysUsers")
@Api(tags = "系统用户")
public class SysUserController extends BaseController<SysUser, SysUserReqVo> {
    @Autowired
    private SysUserService service;
    @Autowired
    private SysUserRoleService userRoleService;

    @Override
    protected IService<SysUser> getService() {
        return service;
    }

    @Override
    protected SysUser getPo(SysUserReqVo reqVo) {
        return MapStructs.INSTANCE.reqVo2po(reqVo);
    }

    @GetMapping("/captcha")
    @ApiOperation("获取验证码")
    public ModelAndView captcha(HttpServletRequest request,
                                HttpServletResponse response) throws Exception {
        CaptchaUtil.out(request, response);
        return null;
    }

    @PostMapping("/login")
    @ApiOperation("登录")
    public DataJsonVo<LoginVo> login(@Valid LoginReqVo loginVo, HttpServletRequest request) {
        if (CaptchaUtil.ver(loginVo.getCaptcha(), request)) {
            return JsonVos.ok(service.login(loginVo));
        } else {
            return JsonVos.raise(CodeMsg.WRONG_CAPTCHA);
        }
    }

    @GetMapping
    @ApiOperation("分页查询")
    @RequiresPermissions(Constants.Permisson.SYS_USER_LIST)
    public ListJsonVo<SysUserVo> list(SysUserListReqVo reqVo) {
        return JsonVos.ok(service.list(reqVo));
    }

    @GetMapping("/roleIds")
    @ApiOperation("查询某个用户下的所有角色ID")
    @RequiresPermissions(Constants.Permisson.SYS_USER_LIST)
    public DataJsonVo<List<Short>> listRoleIds(Integer id) {
        return JsonVos.ok(userRoleService.listRoleIdsByUserId(id));
    }

    @Override
    @RequiresPermissions(Constants.Permisson.SYS_USER_REMOVE)
    public JsonVo remove(String id) {
        return super.remove(id);
    }

    @RequiresPermissions(value = {
            Constants.Permisson.SYS_USER_ADD,
            Constants.Permisson.SYS_USER_UPDATE
    }, logical = Logical.AND)
    @Override
    public JsonVo save(SysUserReqVo reqVo) {
        return service.save(reqVo)
                ? JsonVos.ok(CodeMsg.SAVE_OK)
                : JsonVos.raise(CodeMsg.SAVE_ERROR);
    }
}