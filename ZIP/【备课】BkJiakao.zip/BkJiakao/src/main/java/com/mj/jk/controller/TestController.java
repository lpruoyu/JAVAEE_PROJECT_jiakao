package com.mj.jk.controller;

import com.mj.jk.common.cache.EhCaches;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test")
public class TestController {
    @GetMapping("/tokenPut")
    @ApiOperation("放值")
    public String tokenPut(@RequestParam String key, @RequestParam String value) {
//        EhCaches.tokenPut(key + "1", value);
//        EhCaches.tokenPut(key + "2", value);
//        EhCaches.tokenPut(key + "3", value);
        return "成功";
    }

    @GetMapping("/tokenGet")
    @ApiOperation("取值")
    public String tokenGet(@RequestParam String key) {
//        String value = EhCaches.tokenGet(key + "3");
//        return value == null ? "已经过期" : value;
        return null;
    }
}
