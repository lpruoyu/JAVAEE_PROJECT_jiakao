package com.mj.jk.filter;

import javax.servlet.*;
import java.io.IOException;

public class ErrorFilter implements Filter {
    public static final String ERROR_FILTER = "error_filter";
    public static final String ERROR_FILTER_URI = "/error/filter";

    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        try {
            chain.doFilter(request, response);
        } catch (Throwable e) {
            request.setAttribute(ERROR_FILTER, e);
            request.getRequestDispatcher(ERROR_FILTER_URI).forward(request, response);
        }
    }
}
