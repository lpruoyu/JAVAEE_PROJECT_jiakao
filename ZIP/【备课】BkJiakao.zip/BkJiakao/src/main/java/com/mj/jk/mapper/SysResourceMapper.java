package com.mj.jk.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mj.jk.pojo.po.SysResource;

public interface SysResourceMapper extends BaseMapper<SysResource> {
}