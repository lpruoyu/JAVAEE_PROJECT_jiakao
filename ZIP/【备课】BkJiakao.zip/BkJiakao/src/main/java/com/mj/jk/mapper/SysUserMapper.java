package com.mj.jk.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mj.jk.pojo.dto.SysUserDto;
import com.mj.jk.pojo.po.SysUser;

public interface SysUserMapper extends BaseMapper<SysUser> {
    SysUserDto selectUser(String username);
}