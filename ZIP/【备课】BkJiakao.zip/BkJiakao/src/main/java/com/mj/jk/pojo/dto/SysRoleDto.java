package com.mj.jk.pojo.dto;

import com.mj.jk.pojo.po.SysRole;

public class SysRoleDto extends SysRole {
}
