package com.mj.jk.pojo.vo.req.list;

public class SysRoleListReqVo extends KeywordListReqVo {

}