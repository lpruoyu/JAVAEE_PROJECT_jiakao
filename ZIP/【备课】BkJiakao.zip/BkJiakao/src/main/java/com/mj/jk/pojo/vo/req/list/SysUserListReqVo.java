package com.mj.jk.pojo.vo.req.list;

public class SysUserListReqVo extends KeywordListReqVo {
}
