package com.mj.jk.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mj.jk.pojo.po.ExamPlaceCourse;
import com.mj.jk.pojo.po.Image;
import com.mj.jk.pojo.vo.req.list.ExamPlaceCourseListReqVo;
import com.mj.jk.pojo.vo.list.ExamPlaceCourseVo;
import com.mj.jk.pojo.vo.list.ListVo;
import com.mj.jk.pojo.vo.req.save.ExamPlaceCourseReqVo;

public interface ExamPlaceCourseService
        extends IService<ExamPlaceCourse> {
    ListVo<ExamPlaceCourseVo> list(ExamPlaceCourseListReqVo reqVo);
    boolean saveOrUpdate(ExamPlaceCourseReqVo course, Image cover);
}