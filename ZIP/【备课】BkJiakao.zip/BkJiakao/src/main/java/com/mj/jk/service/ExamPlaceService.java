package com.mj.jk.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mj.jk.pojo.vo.ProvinceVo;
import com.mj.jk.pojo.po.ExamPlace;
import com.mj.jk.pojo.vo.list.ExamPlaceVo;
import com.mj.jk.pojo.vo.req.list.ExamPlaceListReqVo;
import com.mj.jk.pojo.vo.list.ListVo;

import java.util.List;

public interface ExamPlaceService
        extends IService<ExamPlace> {
    ListVo<ExamPlaceVo> list(ExamPlaceListReqVo reqVo);
    List<ProvinceVo> listRegionExamPlaces();
    List<ExamPlace> list(Integer provinId, Integer cityId);
}
