package com.mj.jk.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mj.jk.pojo.po.Image;

import java.util.List;

public interface ImageService
        extends IService<Image> {
    List<Image> list(Long ownerId, Short type);
    boolean remove(Long ownerId, Short type);
}
