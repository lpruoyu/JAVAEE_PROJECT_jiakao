package com.mj.jk.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mj.jk.pojo.vo.ProvinceVo;
import com.mj.jk.pojo.po.PlateRegion;
import com.mj.jk.pojo.vo.list.PlateRegionVo;
import com.mj.jk.pojo.vo.req.list.CityListReqVo;
import com.mj.jk.pojo.vo.req.list.ProvinceListReqVo;
import com.mj.jk.pojo.vo.list.ListVo;

import java.util.List;

public interface PlateRegionService
        extends IService<PlateRegion> {
    ListVo<PlateRegionVo> listProvinces(ProvinceListReqVo reqVo);
    ListVo<PlateRegionVo> listCities(CityListReqVo reqVo);

    List<PlateRegionVo> listProvinces();
    List<ProvinceVo> listRegions();
}
