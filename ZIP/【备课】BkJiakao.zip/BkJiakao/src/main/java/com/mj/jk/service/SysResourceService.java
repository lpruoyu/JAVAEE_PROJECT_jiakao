package com.mj.jk.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mj.jk.pojo.po.SysResource;
import com.mj.jk.pojo.vo.list.SysResourceTreeVo;
import com.mj.jk.pojo.vo.list.SysResourceVo;

import java.util.List;

public interface SysResourceService extends IService<SysResource> {
    List<SysResourceVo> listParents();
    List<SysResourceTreeVo> listTrees();
}