package com.mj.jk.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mj.jk.pojo.po.SysRole;
import com.mj.jk.pojo.vo.list.SysRoleVo;
import com.mj.jk.pojo.vo.req.list.SysRoleListReqVo;
import com.mj.jk.pojo.vo.list.ListVo;
import com.mj.jk.pojo.vo.req.save.SysRoleReqVo;

public interface SysRoleService extends IService<SysRole> {
    ListVo<SysRoleVo> list(SysRoleListReqVo reqVo);
    boolean save(SysRoleReqVo reqVo);
}