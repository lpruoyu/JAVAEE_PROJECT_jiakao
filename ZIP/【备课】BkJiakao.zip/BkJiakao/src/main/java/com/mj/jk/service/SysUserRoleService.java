package com.mj.jk.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mj.jk.pojo.po.SysRole;
import com.mj.jk.pojo.po.SysUser;
import com.mj.jk.pojo.po.SysUserRole;

import java.util.List;

public interface SysUserRoleService extends IService<SysUserRole> {
    boolean removeByUserId(Integer userId);
    List<Short> listRoleIdsByUserId(Integer userId);
}