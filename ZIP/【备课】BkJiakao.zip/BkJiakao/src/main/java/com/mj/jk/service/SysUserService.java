package com.mj.jk.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mj.jk.pojo.po.SysUser;
import com.mj.jk.pojo.vo.LoginVo;
import com.mj.jk.pojo.vo.list.SysUserVo;
import com.mj.jk.pojo.vo.req.LoginReqVo;
import com.mj.jk.pojo.vo.req.list.SysUserListReqVo;
import com.mj.jk.pojo.vo.list.ListVo;
import com.mj.jk.pojo.vo.req.save.SysUserReqVo;

import java.util.List;

public interface SysUserService extends IService<SysUser> {
    ListVo<SysUserVo> list(SysUserListReqVo reqVo);
    boolean save(SysUserReqVo reqVo);
    LoginVo login(LoginReqVo loginReqVo);
}