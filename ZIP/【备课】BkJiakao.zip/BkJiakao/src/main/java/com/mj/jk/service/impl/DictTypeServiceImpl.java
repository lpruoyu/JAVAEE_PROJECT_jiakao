package com.mj.jk.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mj.jk.common.enhance.MpPage;
import com.mj.jk.common.enhance.MpLambdaQueryWrapper;
import com.mj.jk.common.mapStruct.MapStructs;
import com.mj.jk.mapper.DictTypeMapper;
import com.mj.jk.pojo.po.DictType;
import com.mj.jk.pojo.vo.list.DictTypeVo;
import com.mj.jk.pojo.vo.req.list.DictTypeListReqVo;
import com.mj.jk.pojo.vo.list.ListVo;
import com.mj.jk.service.DictTypeService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class DictTypeServiceImpl
        extends ServiceImpl<DictTypeMapper, DictType>
        implements DictTypeService {
    @Override
    @Transactional(readOnly = true)
    public ListVo<DictTypeVo> list(DictTypeListReqVo reqVo) {
        MpLambdaQueryWrapper<DictType> wrapper = new MpLambdaQueryWrapper<>();
        wrapper.like(reqVo.getKeyword(),
                DictType::getName,
                DictType::getValue,
                DictType::getIntro);
        wrapper.orderByDesc(DictType::getId);
        return baseMapper
                .selectPage(new MpPage<>(reqVo), wrapper)
                .buildVo(MapStructs.INSTANCE::po2vo);
    }

    @Override
    @Transactional(readOnly = true)
    public List<DictType> list() {
        MpLambdaQueryWrapper<DictType> wrapper = new MpLambdaQueryWrapper<>();
        wrapper.orderByDesc(DictType::getId);
        return baseMapper.selectList(wrapper);
    }
}
