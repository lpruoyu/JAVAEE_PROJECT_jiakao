package com.mj.jk.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mj.jk.common.enhance.MpPage;
import com.mj.jk.common.enhance.MpLambdaQueryWrapper;
import com.mj.jk.common.exception.CommonException;
import com.mj.jk.common.util.Constants;
import com.mj.jk.common.mapStruct.MapStructs;
import com.mj.jk.mapper.ExamPlaceMapper;
import com.mj.jk.pojo.vo.ProvinceVo;
import com.mj.jk.pojo.po.ExamPlace;
import com.mj.jk.pojo.vo.list.ExamPlaceVo;
import com.mj.jk.pojo.vo.req.list.ExamPlaceListReqVo;
import com.mj.jk.pojo.vo.list.ListVo;
import com.mj.jk.service.ExamPlaceService;
import com.mj.jk.service.ImageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

@Service
@Transactional
public class ExamPlaceServiceImpl
        extends ServiceImpl<ExamPlaceMapper, ExamPlace>
        implements ExamPlaceService {
    @Autowired
    private ImageService imageService;

    @Override
    @Transactional(readOnly = true)
    public ListVo<ExamPlaceVo> list(ExamPlaceListReqVo reqVo) {
        MpLambdaQueryWrapper<ExamPlace> wrapper = new MpLambdaQueryWrapper<>();
        wrapper.like(reqVo.getKeyword(), ExamPlace::getName, ExamPlace::getAddress);
        wrapper.eqId(reqVo.getProvinceId(), ExamPlace::getProvinceId);
        wrapper.eqId(reqVo.getCityId(), ExamPlace::getCityId);
        return baseMapper
                .selectPage(new MpPage<>(reqVo), wrapper)
                .buildVo(MapStructs.INSTANCE::po2vo);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProvinceVo> listRegionExamPlaces() {
        return baseMapper.selectRegionExamPlaces();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExamPlace> list(Integer provinceId, Integer cityId) {
        MpLambdaQueryWrapper<ExamPlace> wrapper = new MpLambdaQueryWrapper<>();
        if (cityId != null && cityId > 0) {
            wrapper.eq(ExamPlace::getCityId, cityId);
            return baseMapper.selectList(wrapper);
        } else if (provinceId != null && provinceId > 0) {
            wrapper.eq(ExamPlace::getProvinceId, provinceId);
            return baseMapper.selectList(wrapper);
        }
        return null;
    }

    @Override
    public boolean removeById(Serializable id) {
        if (!super.removeById(id)) return false;
        removeRoute(id);
        return true;
    }

    @Override
    public boolean removeByIds(Collection<? extends Serializable> idList) {
        if (!super.removeByIds(idList)) return false;
        for (Serializable id : idList) {
            removeRoute(id);
        }
        return true;
    }

    private void removeRoute(Serializable id) {
        // 删除路线图
        if (!imageService.remove(
                Long.parseLong(id.toString()),
                Constants.ImageType.ROUTE)) {
            throw new CommonException();
        }
    }
}
