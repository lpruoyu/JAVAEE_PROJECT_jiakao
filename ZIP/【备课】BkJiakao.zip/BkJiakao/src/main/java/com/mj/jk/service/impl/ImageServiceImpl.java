package com.mj.jk.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mj.jk.common.enhance.MpLambdaQueryWrapper;
import com.mj.jk.common.util.Uploads;
import com.mj.jk.mapper.ImageMapper;
import com.mj.jk.pojo.po.Image;
import com.mj.jk.service.ImageService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

@Service
@Transactional
public class ImageServiceImpl
        extends ServiceImpl<ImageMapper, Image>
        implements ImageService {
    @Override
    @Transactional(readOnly = true)
    public List<Image> list(Long ownerId, Short type) {
        MpLambdaQueryWrapper<Image> wrapper = new MpLambdaQueryWrapper<>();
        wrapper.eq(Image::getOwnerId, ownerId)
                .eq(Image::getType, type);
        return baseMapper.selectList(wrapper);
    }

    @Override
    public boolean remove(Long ownerId, Short type) {
        MpLambdaQueryWrapper<Image> wrapper = new MpLambdaQueryWrapper<>();
        wrapper.eq(Image::getOwnerId, ownerId)
                .eq(Image::getType, type);
        List<Image> images = baseMapper.selectList(wrapper);
        if (baseMapper.delete(wrapper) <= 0) return false;
        Uploads.remove(images);
        return true;
    }

    @Override
    public boolean removeById(Serializable id) {
        Image image = baseMapper.selectById(id);
        if (!super.removeById(id)) return false;
        Uploads.remove(image);
        return true;
    }

    @Override
    public boolean removeByIds(Collection<? extends Serializable> idList) {
        List<Image> images = baseMapper.selectBatchIds(idList);
        if (!super.removeByIds(idList)) return false;
        for (Image image : images) {
            Uploads.remove(image);
        }
        return true;
    }
}
