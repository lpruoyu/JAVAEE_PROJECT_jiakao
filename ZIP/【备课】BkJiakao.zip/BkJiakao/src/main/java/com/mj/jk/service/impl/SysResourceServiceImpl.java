package com.mj.jk.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mj.jk.common.enhance.MpLambdaQueryWrapper;
import com.mj.jk.common.util.Constants;
import com.mj.jk.common.mapStruct.MapStructs;
import com.mj.jk.common.util.Streams;
import com.mj.jk.mapper.SysResourceMapper;
import com.mj.jk.pojo.po.SysResource;
import com.mj.jk.pojo.vo.list.SysResourceTreeVo;
import com.mj.jk.pojo.vo.list.SysResourceVo;
import com.mj.jk.service.SysResourceService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class SysResourceServiceImpl extends ServiceImpl<SysResourceMapper, SysResource> implements SysResourceService {
    @Override
    @Transactional(readOnly = true)
    public List<SysResourceVo> listParents() {
        MpLambdaQueryWrapper<SysResource> wrapper = new MpLambdaQueryWrapper<>();
        wrapper.ne(SysResource::getType, Constants.SysResourceType.BTN);
        wrapper.orderByAsc(SysResource::getType, SysResource::getSn);
        return Streams.map(baseMapper.selectList(wrapper), MapStructs.INSTANCE::po2vo);
    }

    @Override
    public List<SysResourceTreeVo> listTrees() {
        Map<Short, SysResourceTreeVo> cache = new HashMap<>();
        List<SysResourceTreeVo> trees = new ArrayList<>();
        MpLambdaQueryWrapper<SysResource> wrapper = new MpLambdaQueryWrapper<>();
        wrapper.orderByAsc(
                SysResource::getType,
                SysResource::getParentId,
                SysResource::getSn);
        List<SysResource> reses = baseMapper.selectList(wrapper);
        for (SysResource res : reses) {
            // 基本操作
            Short id = res.getId();
            SysResourceTreeVo vo = new SysResourceTreeVo();
            vo.setId(id);
            vo.setTitle(res.getName());
            cache.put(id, vo);

            if (res.getType() == 0) { // 目录
                trees.add(vo);
            } else { // 菜单、按钮
                SysResourceTreeVo pvo = cache.get(res.getParentId());
                List<SysResourceTreeVo> children = pvo.getChildren();
                if (children == null) {
                    pvo.setChildren(children = new ArrayList<>());
                }
                children.add(vo);
            }
        }
        return trees;
    }
}