package com.mj.jk.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mj.jk.common.enhance.MpLambdaQueryWrapper;
import com.mj.jk.common.util.Streams;
import com.mj.jk.mapper.SysRoleResourceMapper;
import com.mj.jk.pojo.po.SysRoleResource;
import com.mj.jk.service.SysRoleResourceService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class SysRoleResourceServiceImpl extends ServiceImpl<SysRoleResourceMapper, SysRoleResource> implements SysRoleResourceService {
    @Override
    public boolean removeByRoleId(Short roleId) {
        if (roleId == null || roleId < 1) return false;
        MpLambdaQueryWrapper<SysRoleResource> wrapper = new MpLambdaQueryWrapper<>();
        wrapper.eq(SysRoleResource::getRoleId, roleId);
        return baseMapper.delete(wrapper) > 0;
    }

    @Override
    public List<Short> listResourceIdsByRoleId(Integer roleId) {
        if (roleId == null || roleId < 1) return null;
        MpLambdaQueryWrapper<SysRoleResource> wrapper = new MpLambdaQueryWrapper<>();
        wrapper.select(SysRoleResource::getResourceId);
        wrapper.eq(SysRoleResource::getRoleId, roleId);
        return Streams.map(baseMapper.selectObjs(wrapper), (obj) -> ((Integer) obj).shortValue());
    }
}