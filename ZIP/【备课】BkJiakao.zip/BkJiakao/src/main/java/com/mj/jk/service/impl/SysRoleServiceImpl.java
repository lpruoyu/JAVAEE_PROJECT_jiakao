package com.mj.jk.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mj.jk.common.cache.EhCaches;
import com.mj.jk.common.enhance.MpPage;
import com.mj.jk.common.enhance.MpLambdaQueryWrapper;
import com.mj.jk.common.mapStruct.MapStructs;
import com.mj.jk.common.util.JsonVos;
import com.mj.jk.mapper.SysRoleMapper;
import com.mj.jk.mapper.SysUserRoleMapper;
import com.mj.jk.pojo.po.SysRole;
import com.mj.jk.pojo.po.SysRoleResource;
import com.mj.jk.pojo.po.SysUserRole;
import com.mj.jk.pojo.result.CodeMsg;
import com.mj.jk.pojo.vo.list.SysRoleVo;
import com.mj.jk.pojo.vo.req.list.SysRoleListReqVo;
import com.mj.jk.pojo.vo.list.ListVo;
import com.mj.jk.pojo.vo.req.save.SysRoleReqVo;
import com.mj.jk.service.SysRoleResourceService;
import com.mj.jk.service.SysRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class SysRoleServiceImpl extends ServiceImpl<SysRoleMapper, SysRole> implements SysRoleService {
    @Autowired
    private SysRoleResourceService roleResourceService;
    @Autowired
    private SysUserRoleMapper userRoleMapper;

    @Override
    @Transactional(readOnly = true)
    public ListVo<SysRoleVo> list(SysRoleListReqVo reqVo) {
        MpLambdaQueryWrapper<SysRole> wrapper = new MpLambdaQueryWrapper<>();
        wrapper.like(reqVo.getKeyword(), SysRole::getName);
        wrapper.orderByDesc(SysRole::getId);
        return baseMapper
                .selectPage(new MpPage<>(reqVo), wrapper)
                .buildVo(MapStructs.INSTANCE::po2vo);
    }

    @Override
    public boolean save(SysRoleReqVo reqVo) {
        // 保存角色
        SysRole role = MapStructs.INSTANCE.reqVo2po(reqVo);
        if (!saveOrUpdate(role)) {
            JsonVos.raise(CodeMsg.SAVE_ERROR);
        }

        // 删除角色
        Short oldId = reqVo.getId();
        if (oldId != null && oldId > 0) {
            // 这里返回false，可能代表本身没有任何资源，不代表删除失败
            roleResourceService.removeByRoleId(oldId);

            // 清空相关的缓存
            MpLambdaQueryWrapper<SysUserRole> wrapper = new MpLambdaQueryWrapper<>();
            wrapper.select(SysUserRole::getUserId);
            wrapper.eq(SysUserRole::getRoleId, oldId);
            for (Object userId : userRoleMapper.selectObjs(wrapper)) {
                EhCaches.tokenRemove(EhCaches.get((Serializable) userId));
            }
        }

        // 新角色id处理
        List<Short> resIds = new ArrayList<>();
        String[] resStrs = reqVo.getResourceIds().split(",");
        for (String resStr : resStrs) {
            if (resStr.length() == 0) continue;
            resIds.add(Short.valueOf(resStr));
        }
        if (CollectionUtils.isEmpty(resIds)) return true;

        // 保存新角色
        Short roleId = role.getId();
        for (Short resId : resIds) {
            SysRoleResource ur = new SysRoleResource();
            ur.setResourceId(resId);
            ur.setRoleId(roleId);
            if (!roleResourceService.save(ur)) {
                JsonVos.raise(CodeMsg.OPERATE_ERROR);
            }
        }
        return true;
    }
}