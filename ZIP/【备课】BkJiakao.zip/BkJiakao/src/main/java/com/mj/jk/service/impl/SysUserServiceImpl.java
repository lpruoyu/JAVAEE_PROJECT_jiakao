package com.mj.jk.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mj.jk.common.enhance.MpPage;
import com.mj.jk.common.enhance.MpLambdaQueryWrapper;
import com.mj.jk.common.util.Constants;
import com.mj.jk.common.cache.EhCaches;
import com.mj.jk.common.util.JsonVos;
import com.mj.jk.common.mapStruct.MapStructs;
import com.mj.jk.mapper.SysUserMapper;
import com.mj.jk.pojo.dto.SysUserDto;
import com.mj.jk.pojo.po.SysUser;
import com.mj.jk.pojo.po.SysUserRole;
import com.mj.jk.pojo.vo.LoginVo;
import com.mj.jk.pojo.vo.list.SysUserVo;
import com.mj.jk.pojo.vo.req.LoginReqVo;
import com.mj.jk.pojo.vo.req.list.SysUserListReqVo;
import com.mj.jk.pojo.result.CodeMsg;
import com.mj.jk.pojo.vo.list.ListVo;
import com.mj.jk.pojo.vo.req.save.SysUserReqVo;
import com.mj.jk.service.SysUserRoleService;
import com.mj.jk.service.SysUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;

@Service
@Transactional
@Slf4j
public class SysUserServiceImpl extends ServiceImpl<SysUserMapper, SysUser> implements SysUserService {
    @Autowired
    private SysUserRoleService userRoleService;

    @Override
    @Transactional(readOnly = true)
    public ListVo<SysUserVo> list(SysUserListReqVo reqVo) {
        MpLambdaQueryWrapper<SysUser> wrapper = new MpLambdaQueryWrapper<>();
        wrapper.like(reqVo.getKeyword(),
                SysUser::getNickname,
                SysUser::getUsername);
        wrapper.orderByDesc(SysUser::getId);
        return baseMapper
                .selectPage(new MpPage<>(reqVo), wrapper)
                .buildVo(MapStructs.INSTANCE::po2vo);
    }

    @Override
    public boolean save(SysUserReqVo reqVo) {
        // 保存用户
        SysUser user = MapStructs.INSTANCE.reqVo2po(reqVo);
        if (!saveOrUpdate(user)) {
            JsonVos.raise(CodeMsg.SAVE_ERROR);
        }

        // 删除角色
        Integer oldId = reqVo.getId();
        if (oldId != null && oldId > 0) {
            // 这里返回false，可能代表本身没有任何角色，不代表删除失败
            userRoleService.removeByUserId(oldId);

            // 从缓存中移除
            EhCaches.tokenRemove(EhCaches.get(oldId));
        }

        // 新角色id处理
        List<Short> roleIds = new ArrayList<>();
        String[] roleStrs = reqVo.getRoleIds().split(",");
        for (String roleStr : roleStrs) {
            if (roleStr.length() == 0) continue;
            roleIds.add(Short.valueOf(roleStr));
        }

        if (CollectionUtils.isEmpty(roleIds)) return true;

        // 保存新角色
        Integer userId = user.getId();
        for (Short roleId : roleIds) {
            SysUserRole ur = new SysUserRole();
            ur.setUserId(userId);
            ur.setRoleId(roleId);
            if (!userRoleService.save(ur)) {
                JsonVos.raise(CodeMsg.OPERATE_ERROR);
            }
        }
        return true;
    }

    @Override
    public LoginVo login(LoginReqVo loginReqVo) {
        SysUserDto user = baseMapper.selectUser(loginReqVo.getUsername());
        if (user == null) {
            return JsonVos.raise(CodeMsg.WRONG_USERNAME);
        }
        if (!loginReqVo.getPassword().equals(user.getPassword())) {
            return JsonVos.raise(CodeMsg.WRONG_PASSWORD);
        }
        if (user.getStatus() == Constants.SysUserStatus.LOCKED) {
            return JsonVos.raise(CodeMsg.LOCKED_ACCOUNT);
        }

        // 更新登录时间
        user.setLoginTime(new Date());
        baseMapper.updateById(user);

        // 生成token
        String token = UUID.randomUUID().toString();

        // 放入缓存
        EhCaches.tokenPut(token, user);

        LoginVo vo = MapStructs.INSTANCE.po2loginVo(user);
        vo.setToken(token);
        return vo;
    }
}