package com.mj.jk;

import com.mj.jk.pojo.po.SysUser;
import com.mj.jk.service.SysUserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class UnitTest {
    @Autowired
    private SysUserService sysUserService;

    @Test
    public void testUser() {
        for (SysUser sysUser : sysUserService.list()) {
            System.out.println(sysUser);
        }
    }
}
