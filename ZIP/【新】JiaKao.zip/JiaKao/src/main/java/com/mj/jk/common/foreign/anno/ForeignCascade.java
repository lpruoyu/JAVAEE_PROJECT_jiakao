package com.mj.jk.common.foreign.anno;

public enum ForeignCascade {
    DEFAULT, DELETE
}
