package com.mj.jk.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mj.jk.pojo.po.SysRole;

public interface SysRoleMapper extends BaseMapper<SysRole> {

}