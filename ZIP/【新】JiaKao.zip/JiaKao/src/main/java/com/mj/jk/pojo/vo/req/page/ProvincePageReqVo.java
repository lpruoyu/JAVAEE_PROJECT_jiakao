package com.mj.jk.pojo.vo.req.page;

public class ProvincePageReqVo extends KeywordPageReqVo {

}
