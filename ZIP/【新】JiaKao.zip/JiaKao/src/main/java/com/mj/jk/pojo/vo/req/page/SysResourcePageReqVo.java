package com.mj.jk.pojo.vo.req.page;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class SysResourcePageReqVo extends KeywordPageReqVo {

}
