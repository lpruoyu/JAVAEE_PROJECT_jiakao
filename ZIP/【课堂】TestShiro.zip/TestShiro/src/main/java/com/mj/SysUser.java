package com.mj;

import lombok.Data;

@Data
public class SysUser {
    private String usenrname;
    private String password;
}
