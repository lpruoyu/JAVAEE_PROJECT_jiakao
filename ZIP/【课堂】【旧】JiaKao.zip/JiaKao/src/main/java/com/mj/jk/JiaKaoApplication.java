package com.mj.jk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JiaKaoApplication {
    public static void main(String[] args) {
        SpringApplication.run(JiaKaoApplication.class, args);
    }
}
