package com.mj.jk.common.util;

public class Constants {
    public static class SysUserStatus {
        public static final int NORMAL = 0;
        public static final int LOCKED = 1;
    }
}
