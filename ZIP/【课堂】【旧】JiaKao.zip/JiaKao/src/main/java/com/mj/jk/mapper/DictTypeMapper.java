package com.mj.jk.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mj.jk.pojo.po.DictType;

public interface DictTypeMapper extends BaseMapper<DictType> {

}