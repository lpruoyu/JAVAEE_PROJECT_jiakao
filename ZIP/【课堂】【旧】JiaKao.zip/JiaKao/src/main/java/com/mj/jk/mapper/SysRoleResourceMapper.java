package com.mj.jk.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mj.jk.pojo.po.SysRoleResource;

public interface SysRoleResourceMapper extends BaseMapper<SysRoleResource> {

}