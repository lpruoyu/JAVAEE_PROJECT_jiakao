package com.mj.jk.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mj.jk.pojo.po.SysUserRole;

public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {

}