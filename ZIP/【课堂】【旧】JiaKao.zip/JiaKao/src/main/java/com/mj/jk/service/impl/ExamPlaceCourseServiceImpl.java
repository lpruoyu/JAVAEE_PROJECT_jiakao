package com.mj.jk.service.impl;

import com.baomidou.mybatisplus.core.toolkit.LambdaUtils;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mj.jk.common.enhance.MpPage;
import com.mj.jk.common.enhance.MpQueryWrapper;
import com.mj.jk.mapper.ExamPlaceCourseMapper;
import com.mj.jk.pojo.po.ExamPlaceCourse;
import com.mj.jk.pojo.vo.PageVo;
import com.mj.jk.pojo.vo.list.ExamPlaceCourseVo;
import com.mj.jk.pojo.vo.req.page.ExamPlaceCoursePageReqVo;
import com.mj.jk.service.ExamPlaceCourseService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ExamPlaceCourseServiceImpl extends ServiceImpl<ExamPlaceCourseMapper, ExamPlaceCourse> implements ExamPlaceCourseService {

    @Override
    @Transactional(readOnly = true)
    public PageVo<ExamPlaceCourseVo> list(ExamPlaceCoursePageReqVo query) {
        MpQueryWrapper<ExamPlaceCourseVo> wrapper = new MpQueryWrapper<>();
        Integer placeId = query.getPlaceId();
        Integer provinceId = query.getProvinceId();
        Integer cityId = query.getCityId();
        Short type = query.getType();
        // 类型
        if (type != null && type >= 0) {
            wrapper.eq("c.type", type);
        }

        // 考场 -> 城市 -> 省份
        if (placeId != null && placeId > 0) {
            wrapper.eq("c.place_id", placeId);
        } else  if (cityId != null && cityId > 0) {
            wrapper.eq("p.city_id", cityId);
        } else if (provinceId != null && provinceId > 0) {
            wrapper.eq("p.province_id", provinceId);
        }

        // 关键词
        wrapper.like(query.getKeyword(), "c.name", "c.intro");
        return baseMapper
                .selectPageVos(new MpPage<>(query), wrapper)
                .buildVo();

        // SELECT COUNT(*) FROM exam_place_course c WHERE (province_id = ?)
        // SELECT COUNT(*) FROM exam_place_course c WHERE (city_id = ?)

//        MpQueryWrapper<ExamPlaceCourseVo> wrapper = new MpQueryWrapper<>();
//        Integer placeId = query.getPlaceId();
//        Integer provinceId = query.getProvinceId();
//        Integer cityId = query.getCityId();
//        Short type = query.getType();
//        // 类型
//        if (type != null && type >= 0) {
//            wrapper.eq(ExamPlaceCourseVo::getType, type);
//        }
//        // 考场 -> 城市 -> 省份
//        if (placeId != null && placeId > 0) {
//            wrapper.eq(ExamPlaceCourseVo::getPlaceId, placeId);
//        } else  if (cityId != null && cityId > 0) {
//            wrapper.eq(ExamPlaceCourseVo::getCityId, cityId);
//        } else if (provinceId != null && provinceId > 0) {
//            wrapper.eq(ExamPlaceCourseVo::getProvinceId, provinceId);
//        }
//        // 关键词
//        wrapper.like(query.getKeyword(), ExamPlaceCourseVo::getName, ExamPlaceCourseVo::getIntro);
//        return baseMapper
//                .selectPageVos(new MpPage<>(query), wrapper)
//                .buildVo();
        // 通过province_id查询时：Unknown column 'province_id' in 'where clause'
        // 通过province_id查询时：Unknown column 'city_id' in 'where clause'
        // 通过name查询时：Column 'name' in where clause is ambiguous
    }
}