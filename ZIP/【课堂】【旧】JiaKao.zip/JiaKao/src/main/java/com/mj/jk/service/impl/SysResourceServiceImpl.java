package com.mj.jk.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mj.jk.common.enhance.MpLambdaQueryWrapper;
import com.mj.jk.common.enhance.MpPage;
import com.mj.jk.common.mapStruct.MapStructs;
import com.mj.jk.mapper.SysResourceMapper;
import com.mj.jk.pojo.po.SysResource;
import com.mj.jk.pojo.po.SysRole;
import com.mj.jk.pojo.vo.PageVo;
import com.mj.jk.pojo.vo.list.SysResourceVo;
import com.mj.jk.pojo.vo.req.page.SysResourcePageReqVo;
import com.mj.jk.service.SysResourceService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class SysResourceServiceImpl extends ServiceImpl<SysResourceMapper, SysResource> implements SysResourceService {

    @Override
    @Transactional(readOnly = true)
    public PageVo<SysResourceVo> list(SysResourcePageReqVo reqVo) {
        MpLambdaQueryWrapper<SysResource> wrapper = new MpLambdaQueryWrapper<>();
        wrapper.like(reqVo.getKeyword(),
                SysResource::getName,
                SysResource::getUri,
                SysResource::getPermission);
        wrapper.orderByDesc(SysResource::getId);
        return baseMapper
                .selectPage(new MpPage<>(reqVo), wrapper)
                .buildVo(MapStructs.INSTANCE::po2vo);
    }
}