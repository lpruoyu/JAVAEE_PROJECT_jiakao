package com.mj.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mj.po.User;

public interface UserService extends IService<User> {

}