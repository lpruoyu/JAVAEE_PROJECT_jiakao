package com.mj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeFeApplication {
    public static void main(String[] args) {
        SpringApplication.run(BeFeApplication.class, args);
    }
}
